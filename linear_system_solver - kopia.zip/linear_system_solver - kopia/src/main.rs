mod matrice;
mod equation_solver;
mod command_line_interface;

use command_line_interface::*;

fn main() {
    run();
}